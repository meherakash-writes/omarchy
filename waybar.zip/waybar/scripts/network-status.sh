#!/usr/bin/env bash

# Auto-detect the connected WiFi interface instead of hardcoding it
# (interface names like wlp0s20f0u8u4 change when USB dongles are replugged,
#  and the internal card here is wlp2s0).
IFACE=$(nmcli -t -f DEVICE,TYPE,STATE dev status 2>/dev/null | awk -F: '$2=="wifi" && $3~/connected/ {print $1; exit}')
if [ -z "$IFACE" ]; then
  IFACE=$(nmcli -t -f DEVICE,TYPE dev status 2>/dev/null | awk -F: '$2=="wifi" {print $1; exit}')
fi
if [ -z "$IFACE" ]; then
  echo '{"text": "󰤭  disconnected", "class": "disconnected"}'
  exit 0
fi

wifi_state=$(cat /sys/class/net/${IFACE}/operstate 2>/dev/null)
if [ "$wifi_state" != "up" ]; then
  echo '{"text": "󰤭  disconnected", "class": "disconnected"}'
  exit 0
fi

ssid=$(iw dev ${IFACE} link 2>/dev/null | awk -F': ' '/SSID:/{print $2}')
if [ -z "$ssid" ]; then
  ssid=$(nmcli -t -f ACTIVE,SSID dev wifi 2>/dev/null | grep '^yes' | head -1 | cut -d: -f2-)
fi
signal=$(iw dev ${IFACE} link 2>/dev/null | awk '/signal:/{print $2}')
if ! [[ "$signal" =~ ^-?[0-9]+$ ]]; then
  # Fallback to NetworkManager's 0-100 signal if iw gives nothing usable
  signal=$(nmcli -t -f ACTIVE,SIGNAL dev wifi 2>/dev/null | awk -F: '$1=="yes" {print $2; exit}')
  if [[ "$signal" =~ ^[0-9]+$ ]]; then
    strength=$signal
    [ $strength -gt 100 ] && strength=100
    [ $strength -lt 0 ] && strength=0
    echo "{\"text\": \"󰤨  ${ssid:-${IFACE}}  ${strength}%\", \"tooltip\": \"${IFACE}: $(nmcli -t -f IP4.ADDRESS dev show ${IFACE} 2>/dev/null | head -1 | cut -d: -f2-)\", \"class\": \"connected\"}"
    exit 0
  fi
  signal=0
fi
strength=$(( (signal + 100) * 100 / 70 ))
[ $strength -gt 100 ] && strength=100
[ $strength -lt 0 ] && strength=0

echo "{\"text\": \"󰤨  ${ssid:-${IFACE}}  ${strength}%\", \"tooltip\": \"${IFACE}: $(nmcli -t -f IP4.ADDRESS dev show ${IFACE} 2>/dev/null | head -1 | cut -d: -f2-)\", \"class\": \"connected\"}"
