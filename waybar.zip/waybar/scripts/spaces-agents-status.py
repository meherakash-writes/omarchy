#!/usr/bin/env python3
"""Waybar custom module: coding-agent status badges.

Shows a spinner while an agent works, a pulsing `!` when one needs input,
and a check mark when one is done -- the Waybar twin of the Spaces
agent badges. Empty (hidden) when nothing is reporting.
"""

import html
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spaces_common import (
    FOCUS_FILE,
    LIVE,
    RANK,
    agent_owners,
    clients_by_pid,
    ensure_dir,
    load_state,
    prune,
)

FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
MARK = {"working": "◌", "waiting": "!", "done": "✓"}


def main():
    sessions = prune(load_state())
    by_pid = clients_by_pid()
    owner = agent_owners(sessions, by_pid)

    wins = []
    for pid, (state, sid) in owner.items():
        client = by_pid[pid]
        ws = (client.get("workspace") or {}).get("id", "?")
        wins.append({
            "pid": pid,
            "state": state,
            "session": sid,
            "class": client.get("class") or "?",
            "title": (client.get("title") or "")[:60],
            "ws": ws,
            "address": client.get("address") or "",
            "focused": client.get("focusHistoryID") == 0,
        })

    if not wins:
        print(json.dumps({"text": "", "tooltip": "No agents reporting",
                          "class": ["idle"]}))
        return 0

    wins.sort(key=lambda w: (-RANK[w["state"]], not w["focused"]))
    live = [w for w in wins if w["state"] in LIVE]
    best = (live or wins)[0]["state"]
    count = sum(1 for w in wins if w["state"] == best)

    if best == "working":
        text = FRAMES[int(time.time() * 2) % len(FRAMES)]
        if count > 1:
            text += " %d" % count
    elif best == "waiting":
        text = "!" if count == 1 else "!%d" % count
    else:
        text = "✓" if count == 1 else "✓%d" % count

    tip = ["%s <b>%s</b> — %s  (ws %s)" % (
        MARK[w["state"]], html.escape(w["class"]),
        html.escape(w["title"]), w["ws"]) for w in wins]

    print(json.dumps({"text": text, "tooltip": "\n".join(tip),
                      "class": [best]}))

    ensure_dir()
    with open(FOCUS_FILE, "w") as f:
        json.dump({"address": wins[0]["address"]}, f)
    return 0


if __name__ == "__main__":
    sys.exit(main())
