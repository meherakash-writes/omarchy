#!/bin/bash
status=$(omarchy battery status 2>/dev/null) || exit 1
present=$(omarchy battery present 2>/dev/null)
[ "$present" != "true" ] && exit 0

capacity=$(cat /sys/class/power_supply/BAT0/capacity 2>/dev/null) || exit 1
charging=$(cat /sys/class/power_supply/BAT0/status 2>/dev/null)

if [ "$charging" = "Charging" ]; then
  icon="󰂄"
elif [ "$capacity" -le 15 ]; then icon="󰁺"
elif [ "$capacity" -le 30 ]; then icon="󰁼"
elif [ "$capacity" -le 60 ]; then icon="󰁿"
elif [ "$capacity" -le 90 ]; then icon="󰂁"
else icon="󰁹"; fi

jq -cn --arg text "$capacity%" --arg icon "$icon" --arg tooltip "Battery: $capacity% ($charging)" \
  '{text: ($icon + " " + $text), tooltip: $tooltip}'
