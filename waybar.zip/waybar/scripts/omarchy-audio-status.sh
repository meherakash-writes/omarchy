#!/bin/bash
sink=$(omarchy audio output sink 2>/dev/null) || exit 1
volume=$(pamixer --get-volume 2>/dev/null)
muted=$(pamixer --get-mute 2>/dev/null)

if [ "$muted" = "true" ]; then
  icon=""
  text="muted"
else
  if [ "$volume" -lt 33 ]; then icon=""
  elif [ "$volume" -lt 66 ]; then icon=""
  else icon=""; fi
  text="$volume%"
fi

jq -cn --arg text "$text" --arg icon "$icon" --arg tooltip "Audio: $sink ($text)" \
  '{text: ($icon + " " + $text), tooltip: $tooltip}'
