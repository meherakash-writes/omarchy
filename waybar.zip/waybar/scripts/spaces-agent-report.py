#!/usr/bin/env python3
"""Report a coding-agent state to the Waybar Spaces widgets.

Waybar twin of `omarchy-shell tornikegomareli.spaces agent ...`:

    spaces-agent-report.py <session> <working|waiting|done|end> <pid,pid,...>

Updates the local agent state file and forwards the report to the Omarchy
Spaces widget as well (best effort), so both bars stay in sync.
"""

import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spaces_common import VALID_STATES, load_state, prune, save_state


def main():
    if len(sys.argv) != 4:
        return 0
    session, state, csv = sys.argv[1], sys.argv[2], sys.argv[3]
    if not session or state not in VALID_STATES:
        return 0
    pids = [int(x) for x in csv.split(",") if x.strip().isdigit() and int(x) > 1]

    sessions = load_state()
    if state == "end":
        sessions.pop(session, None)
    else:
        if not pids:
            return 0
        sessions[session] = {"state": state, "pids": pids, "updated": time.time()}
    save_state(prune(sessions))

    # Forward to the Omarchy bar too; never block (or break) the agent.
    try:
        subprocess.Popen(
            ["omarchy-shell", "tornikegomareli.spaces", "agent",
             session, state, ",".join(str(p) for p in pids)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
