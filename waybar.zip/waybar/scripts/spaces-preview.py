#!/usr/bin/env python3
"""Spaces-style workspace preview + jump for Waybar.

Waybar cannot render live video in a tooltip, so this splits the Spaces
"peek before you jump" idea into what Waybar can do:

  tooltip   live window listing per workspace, refreshed on hover
            (exec module output)
  menu      click: rofi switcher grouped by workspace, select to jump
  shot      right-click: scaled screenshot of the focused monitor (peek)

Usage:
  spaces-preview.py tooltip|menu|shot
"""

import html
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spaces_common import hypr_json

PERSISTENT = range(1, 6)  # matches Spaces persistentWorkspaces default


def workspaces_with_clients():
    monitors = hypr_json(["monitors"])
    active = None
    for m in monitors:
        if m.get("focused"):
            active = ((m.get("activeWorkspace") or {}).get("id"))
            break
    clients = [c for c in hypr_json(["clients"]) if c.get("address")]
    by_ws = {}
    for c in clients:
        ws = (c.get("workspace") or {}).get("id")
        if isinstance(ws, int) and ws > 0:
            by_ws.setdefault(ws, []).append(c)
    for wins in by_ws.values():
        wins.sort(key=lambda c: ((c.get("at") or [0, 0])[0],
                                 (c.get("at") or [0, 0])[1]))
    ids = sorted(set(list(PERSISTENT) + list(by_ws)))
    return ids, by_ws, active


def cmd_tooltip():
    ids, by_ws, active = workspaces_with_clients()
    lines = []
    for wid in ids:
        wins = by_ws.get(wid, [])
        marker = "▶" if wid == active else "·"
        if not wins:
            lines.append("%s <b>%d</b>  <i>empty</i>" % (marker, wid))
            continue
        lines.append("%s <b>%d</b>" % (marker, wid))
        for c in wins:
            title = (c.get("title") or "")[:50]
            lines.append("     %s — %s" % (html.escape(c.get("class") or "?"),
                                           html.escape(title)))
    print(json.dumps({"text": "▦", "tooltip": "\n".join(lines),
                      "class": ["spaces-preview"]}))
    return 0


def cmd_menu():
    ids, by_ws, active = workspaces_with_clients()
    entries, addrs = [], []
    for wid in ids:
        for c in by_ws.get(wid, []):
            star = "▶ " if wid == active else ""
            title = (c.get("title") or "")[:70]
            entries.append("%s ws %d · %s · %s" % (star, wid,
                                                  c.get("class") or "?", title))
            addrs.append(c.get("address"))
    if not entries:
        return 0
    try:
        proc = subprocess.run(
            ["rofi", "-dmenu", "-i", "-p", "Spaces: focus window",
             "-format", "i"],
            input="\n".join(entries) + "\n", capture_output=True,
            text=True, timeout=60,
        )
    except Exception:
        return 0
    if proc.returncode != 0:
        return 0
    try:
        addr = addrs[int(proc.stdout.strip())]
    except (ValueError, IndexError):
        return 0
    subprocess.run(["hyprctl", "dispatch", "focuswindow", "address:" + addr],
                   capture_output=True, timeout=5)
    return 0


def cmd_shot():
    monitors = hypr_json(["monitors"])
    name = next((m.get("name") for m in monitors if m.get("focused")), None)
    if not name:
        return 0
    shot = "/tmp/waybar-spaces-shot.png"
    if subprocess.run(["grim", "-o", name, "-s", "0.3", shot],
                      capture_output=True, timeout=15).returncode != 0:
        return 0
    subprocess.run(["timeout", "8", "imv", shot],
                   capture_output=True, timeout=15)
    return 0


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "tooltip"
    sys.exit({"tooltip": cmd_tooltip, "menu": cmd_menu,
              "shot": cmd_shot}.get(mode, cmd_tooltip)())
