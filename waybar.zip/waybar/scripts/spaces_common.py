"""Shared state + Hyprland helpers for the Waybar Spaces widgets.

Mirrors the matching logic of the Omarchy Spaces plugin (Model.js):
agent pid chains are matched to terminal windows, nearest ancestor wins,
and "waiting" outranks "working" outranks "done".
"""

import json
import os
import subprocess

STATE_DIR = os.path.join(
    os.environ.get("XDG_STATE_HOME", os.path.expanduser("~/.local/state")),
    "waybar-spaces",
)
STATE_FILE = os.path.join(STATE_DIR, "agents.json")
FOCUS_FILE = os.path.join(STATE_DIR, "focus.json")

RANK = {"waiting": 3, "working": 2, "done": 1}
LIVE = {"working", "waiting"}
VALID_STATES = {"working", "waiting", "done", "end"}


def ensure_dir():
    os.makedirs(STATE_DIR, exist_ok=True)


def load_state():
    """Return {session: {state, pids, updated}} (empty on missing/corrupt file)."""
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
        sessions = data.get("sessions", {})
        return sessions if isinstance(sessions, dict) else {}
    except (FileNotFoundError, ValueError, OSError):
        return {}


def save_state(sessions):
    ensure_dir()
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"sessions": sessions}, f)
    os.replace(tmp, STATE_FILE)


def pid_alive(pid):
    """True if pid exists and is not a zombie (same probe Spaces uses)."""
    try:
        with open("/proc/%d/stat" % pid) as f:
            stat = f.read()
    except OSError:
        return False
    rest = stat[stat.rindex(")") + 1:].strip().split()
    return bool(rest) and rest[0] != "Z"


def prune(sessions):
    """Drop live claims whose agent process is gone.

    Finished and malformed entries are preserved: this is crash cleanup,
    not state validation (mirrors Spaces Model.pruneDeadAgents).
    """
    out = {}
    for sid, agent in sessions.items():
        if not isinstance(agent, dict):
            continue
        state = agent.get("state")
        pids = agent.get("pids") or []
        if state in LIVE:
            try:
                first = int(pids[0])
            except (IndexError, TypeError, ValueError):
                continue
            if not pid_alive(first):
                continue
        out[sid] = agent
    return out


def hypr_json(args):
    try:
        proc = subprocess.run(
            ["hyprctl"] + list(args) + ["-j"],
            capture_output=True, text=True, timeout=5,
        )
        return json.loads(proc.stdout) if proc.returncode == 0 else []
    except Exception:
        return []


def clients_by_pid():
    return {c.get("pid"): c for c in hypr_json(["clients"]) if c.get("pid")}


def agent_owners(sessions, by_pid):
    """Map window pid -> (state, session).

    The nearest ancestor pid that owns a window wins; when several agents
    share a window, waiting beats working beats done.
    """
    owner = {}
    for sid, agent in sessions.items():
        state = agent.get("state")
        if RANK.get(state, 0) == 0:
            continue
        for pid in agent.get("pids") or []:
            try:
                pid = int(pid)
            except (TypeError, ValueError):
                continue
            if pid in by_pid:
                if RANK[state] > RANK.get(owner.get(pid, ("", ""))[0], 0):
                    owner[pid] = (state, sid)
                break
    return owner
