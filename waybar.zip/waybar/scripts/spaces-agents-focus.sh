#!/usr/bin/env bash
# Focus the window behind the Waybar agent badge (most urgent first).
addr=$(python3 -c "import json;print(json.load(open('$HOME/.local/state/waybar-spaces/focus.json')).get('address',''))" 2>/dev/null)
[[ -n $addr ]] && hyprctl dispatch focuswindow "address:$addr" >/dev/null
exit 0
