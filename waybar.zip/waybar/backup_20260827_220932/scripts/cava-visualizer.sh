#!/usr/bin/env bash
# Custom waybar cava module script
# Runs cava in raw mode and outputs waybar JSON with bar characters

CHARS=("▁" "▂" "▃" "▄" "▅" "▆" "▇" "█")
NUM_BARS=8
CONFIG="/tmp/waybar-cava.conf"

cat > "$CONFIG" <<'CAVAEOF'
[general]
framerate = 60
sensitivity = 100
bars = 8
lower_cutoff_freq = 50
higher_cutoff_freq = 10000

[output]
method = raw
raw_target = /dev/stdout
data_format = ascii
ascii_max_range = 15

[input]
method = pulse
source = auto

[smoothing]
integral = 0.2
monstercat = 0.5
waves = 0.0
CAVAEOF

while IFS=';' read -ra values; do
  text=""
  count=0
  for val in "${values[@]}"; do
    if [ $count -ge $NUM_BARS ]; then
      break
    fi
    # Map 0-15 to 0-7
    level=$((val * 7 / 15))
    text+="${CHARS[$level]}"
    ((count++))
  done
  if [ -n "$text" ]; then
    echo "{\"text\": \"$text\", \"tooltip\": \"Cava Audio Visualizer\"}"
  fi
done < <(cava -p "$CONFIG" 2>/dev/null)
