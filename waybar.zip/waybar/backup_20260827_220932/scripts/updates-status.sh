#!/bin/bash
repo=$(checkupdates 2>/dev/null | wc -l)
aur=$(yay -Qua 2>/dev/null | wc -l)
total=$((repo + aur))
ver=$(omarchy version 2>/dev/null)

if [ "$total" -gt 0 ]; then
  text="󰏗 $total"
else
  text=""
fi

tooltip="Omarchy v${ver:-?}"
[ "$total" -gt 0 ] && tooltip="$tooltip
Repo: $repo | AUR: $aur
Click to update" || tooltip="$tooltip
System up to date"

jq -cn --arg text "$text" --arg tooltip "$tooltip" '{text: $text, tooltip: $tooltip}'
