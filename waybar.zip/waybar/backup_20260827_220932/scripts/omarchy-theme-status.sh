#!/bin/bash
theme=$(omarchy theme current 2>/dev/null) || exit 1
slug=$(echo "$theme" | tr '[:upper:]' '[:lower:]' | tr ' ' '-')

jq -cn --arg text "󰸌  $theme" --arg alt "$slug" --arg theme "$theme" \
  '{text: $text, alt: $alt, tooltip: ("Current Theme: " + $theme + "\nClick to open theme switcher")}'
