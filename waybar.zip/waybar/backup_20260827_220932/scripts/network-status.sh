#!/usr/bin/env bash

IFACE="wlp0s20f0u8u4"

wifi_state=$(cat /sys/class/net/${IFACE}/operstate 2>/dev/null)
if [ "$wifi_state" != "up" ]; then
  echo '{"text": "󰤭  disconnected", "class": "disconnected"}'
  exit 0
fi

ssid=$(nmcli -t -f ACTIVE,SSID dev wifi | grep '^yes' | head -1 | cut -d: -f2)
signal=$(iw dev ${IFACE} link 2>/dev/null | awk '/signal:/{print $2}')
if [ -z "$signal" ]; then
  signal=0
fi
strength=$(( (signal + 100) * 100 / 70 ))
[ $strength -gt 100 ] && strength=100

echo "{\"text\": \"󰤨  ${ssid:-${IFACE}}  ${strength}%\", \"tooltip\": \"${IFACE}: $(nmcli -t -f IP4.ADDRESS dev show ${IFACE} | head -1 | cut -d: -f2)\"}"
