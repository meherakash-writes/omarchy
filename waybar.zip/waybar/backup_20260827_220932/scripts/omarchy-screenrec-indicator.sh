#!/usr/bin/env bash

if pgrep -f gpu-screen-recorder > /dev/null 2>&1; then
  jq -cn '{text: "󰑊", alt: "recording", class: "recording", tooltip: "Recording in progress\\nClick to stop"}'
else
  jq -cn '{text: "", alt: "idle", class: "idle", tooltip: "Not recording\\nClick to start screen recording"}'
fi
