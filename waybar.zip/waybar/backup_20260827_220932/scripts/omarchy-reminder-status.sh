#!/bin/bash
output=$(omarchy reminder show --json 2>/dev/null)
count=$(echo "$output" | jq -r '.count // 0')
tooltip=$(echo "$output" | jq -r '.tooltip // "No reminders"')

icon=$(printf '\uf5c3')

if [ "$count" -gt 0 ]; then
  text="$icon $count"
else
  text="$icon"
fi

jq -cn --arg text "$text" --arg tooltip "$tooltip" --argjson count "$count" \
  '{text: $text, tooltip: $tooltip, count: $count}'