#!/bin/bash
if bluetoothctl show 2>/dev/null | grep -q "Powered: yes"; then
  jq -cn '{text: "", alt: "on", class: "on", tooltip: "Bluetooth: On\nClick to turn off"}'
else
  jq -cn '{text: "", alt: "off", class: "off", tooltip: "Bluetooth: Off\nClick to turn on"}'
fi
