#!/bin/bash
count=$(pacman -Qu 2>/dev/null | wc -l)
if [ "$count" -gt 0 ]; then
  text="󰮯 $count"
  tooltip="$count package(s) can be updated"
else
  text=""
  tooltip="System is up to date"
fi
jq -cn --arg text "$text" --arg tooltip "$tooltip" --argjson count "$count" '{text: $text, tooltip: $tooltip, count: $count}'
