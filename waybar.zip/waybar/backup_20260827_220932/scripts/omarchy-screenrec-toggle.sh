#!/bin/bash
if pgrep -f gpu-screen-recorder > /dev/null 2>&1; then
  omarchy capture screenrecording --stop-recording
else
  omarchy capture screenrecording --fullscreen
fi
