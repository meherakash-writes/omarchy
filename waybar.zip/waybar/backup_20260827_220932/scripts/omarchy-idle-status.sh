#!/bin/bash
status=$(omarchy toggle idle --status 2>/dev/null) || exit 1
enabled=$(echo "$status" | jq -r '.enabled')

if [[ "$enabled" == "true" ]]; then
  jq -cn '{text: "", alt: "awake", class: "enabled", tooltip: "Stay Awake\nIdle, lock & screensaver disabled\nClick to allow idle"}'
else
  jq -cn '{text: "", alt: "idle", class: "disabled", tooltip: "Idle enabled\nSystem will lock & sleep normally\nClick to stay awake"}'
fi
