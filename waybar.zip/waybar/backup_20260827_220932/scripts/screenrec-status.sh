#!/bin/bash
if pgrep -f gpu-screen-recorder > /dev/null 2>&1; then
  echo '{"text":"󰑊","tooltip":"Recording in progress...\nClick to stop"}'
else
  echo '{"text":"󰑊","tooltip":"Screen Recording\nClick to start"}'
fi
