#!/bin/bash
weather=$(omarchy weather status 2>/dev/null) || exit 1
jq -cn --arg text "$weather" '{text: $text, tooltip: "Weather: " + $text}'
