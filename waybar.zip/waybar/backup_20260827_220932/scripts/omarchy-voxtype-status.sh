#!/usr/bin/env bash

if ! command -v voxtype >/dev/null 2>&1; then
  jq -cn '{text: "", alt: "idle", class: "idle", tooltip: "Voxtype not installed"}'
  exit 0
fi

timeout 5 voxtype status --extended --format json 2>/dev/null || \
  jq -cn '{text: "", alt: "idle", class: "idle", tooltip: "Voxtype unavailable"}'
