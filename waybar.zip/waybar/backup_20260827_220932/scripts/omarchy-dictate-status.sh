#!/bin/bash
voxtype status --format json --extended --icon-theme nerd-font 2>/dev/null | jq -c '{text: .text, tooltip: .tooltip}'
