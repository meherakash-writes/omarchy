@define-color bg {{bg}};
@define-color fg {{fg}};
@define-color border {{border}};
@define-color row {{row}};
@define-color crimson {{crimson}};
@define-color red {{red}};
@define-color gold {{gold}};
@define-color gold2 {{gold2}};
@define-color mauve {{mauve}};
@define-color pink {{pink}};
@define-color blue {{blue}};
@define-color steel {{steel}};
@define-color slate {{slate}};
@define-color sage {{sage}};
@define-color sage2 {{sage2}};
@define-color slate2 {{slate2}};
@define-color muted {{muted}};
@define-color muted2 {{muted2}};


* {
	border: none;
	border-radius: 10;
	font-family: "Quantum Rangers Personal";
	font-size: 16px;
	min-height: 10px;
}
window#waybar {
	background: transparent;
}
#custom-network {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @gold;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#keyboard-state{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	background: @bg;
	color: @mauve;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#keyboard-state:hover{
	color: @bg;
	background: @mauve;
}
#custom-network:hover {
	color: @bg;
	background: @gold;
}
#custom-keybinds {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	color: @blue;
	background: @bg;
	transition: 0.3s;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
}
#custom-keybinds:hover {
	background: @blue;
	color: @bg;
}
#custom-cava{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @crimson;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#custom-cava:hover{
	color: @bg;
	background: @crimson;
}
#battery{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @sage2;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#battery:hover{
	color: @bg;
	background: @sage2;
}
#backlight:hover{
	color: @bg;
	background: @gold;
}
#backlight{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @gold;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#language{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @pink;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#language:hover{
	color: @bg;
	background: @pink;
}
#pulseaudio {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @slate;
	padding: 8px;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#pulseaudio:hover{
	background: @slate;
	color: @bg;
}
#pulseaudio.muted {
	color: @crimson;
	background: @bg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @crimson;
	transition: 0.3s;
}
#pulseaudio.muted:hover {
	background: @crimson;
	color: @bg;
}
#clock {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @gold2;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#clock:hover {
	color: @bg;
	background: @gold2;
}
#disk{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @red;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#disk:hover{
	color: @bg;
	background: @red;
}
#privacy{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @fg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#idle_inhibitor{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 15px;
	padding-right: 15px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @fg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#idle_inhibitor.activated{
	color: @fg;
	border-color: @fg;
}
#idle_inhibitor.activated:hover{
	background: @fg;
	color: @bg;
	border-color: @fg;
}
#idle_inhibitor.deactivated{
	color: @fg
}
#idle_inhibitor.deactivated:hover{
	color: @bg;
	background: @fg;
}
#memory {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	margin-bottom: 0px;
	padding-right: 10px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @slate2;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#memory:hover {
	color: @bg;
	background: @slate2;
}
#cpu {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	margin-bottom: 0px;
	padding-right: 10px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @sage;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#cpu:hover {
	color: @bg;
	background: @sage;
}
#custom-launcher,#custom-dot {
	font-size: 20px;
	margin-top: 10px;
	margin-left: 17px;
	padding-left: 10px;
	padding-right: 5px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	transition: 0.3s;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
}
#custom-launcher {
	color: @fg;
}
#custom-dot {
	color: @gold;
}
#custom-launcher:hover {
	background: @fg;
	color: @bg;
}
#custom-dot:hover {
	background: @gold;
	color: @bg;
}
#custom-network.disconnected {
	color: @red;
	background: @bg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @red;
}
#custom-network.disconnected:hover {
	background: @red;
	color: @bg;
}
#custom-power {
	font-size: 15px;
	margin-top: 10px;
	margin-left: 8px;
	margin-right: 17px;
	padding-left: 10px;
	padding-right: 5px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @muted2;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#custom-power:hover {
	background: @red;
	color: @bg;
	border-color: @red;
}
#workspaces {
	margin-top: 10px;
	margin-left: 8px;
	padding-right: 4px;
	background: @bg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	color: @fg;
	transition: 0.3s;
}
#workspaces button {
	color: @muted;
	transition: 0.3s;
}
#workspaces button.active {
	color: @crimson;
}
#workspaces button.focused {
	color: @bg;
	background: @mauve;
}
#workspaces button.urgent {
	color: @bg;
	background: @red;
}
#workspaces button:hover {
	background: transparent;
	color: transparent;
}
#tray{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @muted;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#tray menu{
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @fg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#custom-omarchy-weather,
#custom-omarchy-updates,
#custom-omarchy-audio,
#custom-omarchy-battery,
#custom-omarchy-theme,
#custom-omarchy-reminders,
#custom-screenrecording-indicator,
#custom-idle-indicator,
#custom-omarchy-dictate,
#custom-voxtype,
#custom-spaces-preview,
#custom-spaces-agents,
#custom-opencode-agent {
	margin-top: 10px;
	margin-left: 8px;
	padding-left: 10px;
	padding-right: 10px;
	margin-bottom: 0px;
	border-radius: 10px;
	transition: none;
	background: @bg;
	color: @fg;
	border-bottom: 3px;
	border-style: solid;
	border-color: @fg;
	transition: 0.3s;
}
#custom-omarchy-weather:hover,
#custom-omarchy-updates:hover,
#custom-omarchy-audio:hover,
#custom-omarchy-battery:hover,
#custom-omarchy-theme:hover,
#custom-omarchy-reminders:hover,
#custom-screenrecording-indicator:hover,
#custom-idle-indicator:hover,
#custom-omarchy-dictate:hover,
#custom-voxtype:hover,
#custom-spaces-preview:hover,
#custom-spaces-agents:hover,
#custom-opencode-agent:hover {
	color: @bg;
	background: @fg;
}
#custom-opencode-agent {
	color: @gold;
}
#custom-opencode-agent:hover {
	color: @bg;
	background: @gold;
}
#custom-screenrecording-indicator.recording {
	color: @crimson;
}
#custom-screenrecording-indicator.recording:hover {
	color: @bg;
	background: @crimson;
}
#custom-omarchy-updates {
	color: @gold2;
}
#custom-omarchy-updates:hover {
	color: @bg;
	background: @gold2;
}
#custom-omarchy-reminders {
	color: @mauve;
}
#custom-omarchy-reminders:hover {
	color: @bg;
	background: @mauve;
}
#custom-omarchy-weather {
	color: @slate2;
}
#custom-omarchy-weather:hover {
	color: @bg;
	background: @slate2;
}
#custom-omarchy-audio {
	color: @slate;
}
#custom-omarchy-audio:hover {
	color: @bg;
	background: @slate;
}
#custom-idle-indicator {
	color: @sage;
}
#custom-idle-indicator:hover {
	color: @bg;
	background: @sage;
}
#custom-voxtype {
	color: @pink;
}
#custom-voxtype:hover {
	color: @bg;
	background: @pink;
}
#custom-omarchy-dictate {
	color: @steel;
}
#custom-omarchy-dictate:hover {
	color: @bg;
	background: @steel;
}
#custom-omarchy-theme {
	color: @red;
}
#custom-omarchy-theme:hover {
	color: @bg;
	background: @red;
}
#custom-screenrecording-indicator {
	color: @red;
}
#custom-screenrecording-indicator:hover {
	color: @bg;
	background: @red;
}
#custom-spaces-preview {
	color: @blue;
}
#custom-spaces-preview:hover {
	color: @bg;
	background: @blue;
}
#custom-spaces-agents {
	color: @fg;
}
#custom-spaces-agents:hover {
	color: @bg;
	background: @fg;
}
#custom-spaces-agents.working {
	color: @gold2;
}
#custom-spaces-agents.working:hover {
	color: @bg;
	background: @gold2;
}
#custom-spaces-agents.waiting {
	color: @crimson;
	border-color: @crimson;
}
#custom-spaces-agents.waiting:hover {
	color: @bg;
	background: @crimson;
	border-color: @crimson;
}
#custom-spaces-agents.done {
	color: @sage;
}
#custom-spaces-agents.done:hover {
	color: @bg;
	background: @sage;
}
#custom-spaces-agents.idle {
	color: @muted;
}